from flask import Flask, render_template, request, redirect, session
import sqlite3
app = Flask(__name__)
app.secret_key='change-this-secret'

def db():
    c=sqlite3.connect('referral.db'); c.row_factory=sqlite3.Row; return c

def init_db():
    c=db()
    c.execute('CREATE TABLE IF NOT EXISTS promo_codes(id INTEGER PRIMARY KEY, code TEXT UNIQUE, owner TEXT, commission REAL, active INTEGER DEFAULT 1)')
    c.commit(); c.close()

@app.route('/')
def home(): return render_template('home.html')

@app.route('/verify', methods=['GET','POST'])
def verify():
    result=None
    if request.method=='POST':
        c=db()
        result=c.execute('SELECT * FROM promo_codes WHERE code=?',(request.form['code'].upper(),)).fetchone()
        c.close()
    return render_template('verify.html', result=result)

@app.route('/admin', methods=['GET','POST'])
def admin():
    if request.method=='POST' and request.form['password']=='admin123':
        session['admin']=True
        return redirect('/dashboard')
    return render_template('login.html')

@app.route('/dashboard', methods=['GET','POST'])
def dashboard():
    if not session.get('admin'): return redirect('/admin')
    c=db()
    if request.method=='POST':
        c.execute('INSERT INTO promo_codes(code,owner,commission) VALUES(?,?,?)',
                  (request.form['code'].upper(),request.form['owner'],request.form['commission']))
        c.commit()
    rows=c.execute('SELECT * FROM promo_codes').fetchall()
    c.close()
    return render_template('dashboard.html', rows=rows)

if __name__=='__main__':
    init_db()
    app.run(debug=True)
